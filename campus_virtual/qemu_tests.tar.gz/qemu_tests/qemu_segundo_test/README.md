# Trabajo Práctico 1 - QEMU

## Suma Assembler y ABI

Utilizar los fuentes dados para crear los binarios correspondientes y emular en QEMU.

## Multiplicación Assembler y ABI

Realice lo mismo que con `suma` pero implementando la multiplicación entera entre 2 números. 

## División Assembler y ABI

Realice lo mismo que con `suma` pero implementando la división entera entre 2 números.

### ¿Puede realizar operaciones que involucren aritmética de punto flotante? 
### ¿Puede realizar operaciones que involucren aritmética de punto fijo? 


